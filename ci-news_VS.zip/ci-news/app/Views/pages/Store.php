<h2>Esta es la tienda, donde puedes comprar muchos productos</h2>
<a href="home">Volver al Home</a>
<br>

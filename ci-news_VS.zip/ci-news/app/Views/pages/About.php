<!DOCTYPE html>
<html>
<head>
  <title>Registro Vehiculos</title>
  <style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
</style>
</head>
<body>
  <h2>Registro de Vehiculos</h2>

  <form id="customers" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <label for="placa">Placa:</label>
    <input type="text" id="placa" name="placa" required><br><br>

    <label for="marca">Marca:</label>
    <input type="text" id="marca" name="marca" required><br><br>

    <label for="modelo">Modelo:</label>
    <input type="text" id="modelo" name="modelo" required><br><br>

    
    <label for="color">Color:</label>
    <input type="text" id="color" name="color" required><br><br>

    <input type="submit" value="Registrar Cita">
  </form>

  <?php
  // Verificar si se ha enviado el formulario
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener los valores del formulario
    $placa = $_POST["placa"];
    $marca = $_POST["marca"];
    $modelo = $_POST["modelo"];
    $color = $_POST["color"];

    // Mostrar los datos ingresados en una tabla
    echo "<h3>Datos del Vehiculo:</h3>";
    echo "<table>";
    echo "<tr><th>placa</th><th>marca</th><th>modelo</th><th>color</th></tr>";
    echo "<tr><td>$placa</td><td>$marca</td><td>$modelo</td><td>$color</td></tr>";
    echo "</table>";
  }
  ?>
</body>
</html>

<a href="home">Volver al pagina principal</a>
<br>
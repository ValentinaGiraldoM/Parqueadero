<!DOCTYPE html>
<html>
<head>
<style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
</style>
</head>
<body>

<h1>PRECIOS VEHICULOS</h1>

<table id="customers">
  <tr>
    <th>vehiculo</th>
    <th>Precio x Hora</th>
  </tr>
  <tr>
    <td>Carro</td>
    <td>2.000</td>
  </tr>
  <tr>
    <td>Motos</td>
    <td>1.000</td>
  </tr>
  <tr>
    <td>Bicicleta</td>
    <td>500</td>
  </tr>
</table>

</body>
</html>

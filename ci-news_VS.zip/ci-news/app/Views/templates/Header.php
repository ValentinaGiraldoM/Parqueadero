<!doctype html>
<html>
<head>
    <title>Parqueadero</title>
</head>
<body>

    <div>
      <ul >
        <li><a href="home">Página principal</a></li>
        <li><a href="About">Vehiculos</a></li>
        <li><a href="conductor">Conductor</a></li>
        <li><a href="total">Total</a></li>
        <li><a href="#">Salir</a></li>
      </ul>
    </div>
